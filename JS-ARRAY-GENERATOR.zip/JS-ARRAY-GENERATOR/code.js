window.onload=function(){
var button = document.getElementById('btn');
var label = document.getElementById('label');
var places = ["Thalassery", "Kerala", "India", "Barcelona", "Camp Nou" , "Asia" , "Spain", "Tokyo", "Japan", "Madrid"];

button.addEventListener('click', function(){
label.innerHTML=places[Math.floor(Math.random() * 10)];
});


};
